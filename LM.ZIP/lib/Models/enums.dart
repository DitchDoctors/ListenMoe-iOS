enum RadioChoice {
  jpop, kpop
}


enum HTTPMethod {
  get, post, delete, put
}